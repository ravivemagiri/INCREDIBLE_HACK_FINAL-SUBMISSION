from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from store_data_into_es import *
import MySQLdb.cursors
import re
from mailing import *
import pdb
import random
app = Flask(__name__)

# Change this to your secret key (can be anything, it's for extra protection)
app.secret_key = 'your secret key'

# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root@123'
app.config['MYSQL_DB'] = 'pythonlogin'

# Intialize MySQL
mysql = MySQL(app)
@app.route('/', methods=['GET', 'POST'])
def login():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
		# Create variables for easy access
	    username = request.form['username']
	    password = request.form['password']
        # export DYLD_LIBRARY_PATH=/usr/local/mysql/lib/
	    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
	    cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username, password))
	    # Fetch one record and return result
	    account = cursor.fetchone()
	    if account:
	        # Create session data, we can access this data in other routes
	        session['loggedin'] = True
	        session['id'] = account['id']
	        session['username'] = account['username']
	        # Redirect to home page
	        return redirect(url_for('home'))
	    else:
	        # Account doesnt exist or username/password incorrect
	        msg = 'Incorrect username/password!'
	return render_template('index.html', msg='')

@app.route('/banking', methods=['GET', 'POST'])
def banking():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        if username == "banking" and password == "banking":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            number_of_rows = cursor.execute("select * from banking");
            result = cursor.fetchall()
            print(result)
            return render_template('bank_dashboard.html',loan_views=result)
        # export DYLD_LIBRARY_PATH=/usr/local/mysql/lib/
    return render_template('bank_login.html', msg='')


@app.route('/register', methods=['GET', 'POST'])
def register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s', [username])
        account = cursor.fetchone()
        # If account exists show error and validation checks
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            cursor.execute('INSERT INTO accounts VALUES (NULL, %s, %s, %s)', (username, password, email))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
    # Show registration form with message (if any)
    return render_template('register.html', msg=msg)

import json 
def score_calculation(data,list_of_states_and_company):
     
    loan_status = False
    formula_value = ((0.717 * float( data['x1'])) +  (0.847 * float( data['x2'])) +  (3.107 * float( data['x3'])) + (0.42 * float( data['x4'])) + (0.998 * float( data['x5'])))/6.089
    if data['registration_status']:
        if data['COMPANY STATUS'] == 'Active':
            state_information = data['STATE']
            com_desc = data['ACTIVITY DESCRIPTION']
            score = list_of_states_and_company[state_information][com_desc]
            if data['CATEGORY'] =='Company Limited by Guarantee':
                score = 0.5
            else:
                if float(data['AUTHORIZED CAPITAL'])/2 <= float(data['PAIDUP CAPITAL']):
                    score = 0.6
            if score > 0.5 and formula_value > 0.5:
                loan_status = True
            else:
                print("Loan criteria not satisfied. ",score, formula_value)
        else:
            print("Sorry we cannot process your loan because of inactive status of your Company.")
    else:
        print("Company not registered")
    return loan_status

@app.route('/process', methods=['GET', 'POST','post'])
def process():
    msg = ''
    if request.method == 'POST':
        
        cname = request.form['cname']
        cin = request.form['cin']
        reg = request.form['reg']
        rmail = request.form['rmail']
        es_object = Elasticsearch([{'host': 'localhost', 'port': 9200}])
        company_info = get_company_info(es_object, "company_data", cin)
        print(company_info)
        with open('data.json') as data:
            list_of_states_and_company = json. load(data)
        data  = {}
        a=[0,1,2,3,4,5,6,7,8,9]
        tick_num= "#"+str(random.choice(a))+cname[0]+cin[-1]+reg[-1]+str((random.choice(a))*2)
        str3 = "N140976@rguktn.ac.in"
        num_inf = "😁 successfully Generated Ticket for your loan process. Your Ticket: {}. Keep this for future reference".format(tick_num)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        if company_info["registration_status"]:
            name = company_info["COMPANY NAME"]
            loan_res = score_calculation(company_info, list_of_states_and_company)
            if loan_res:
                status = "Yes"
                try:
                    print("ABOVE LINE")
                    ans=mail_details([str3],'ravivarma.vemagiri@gmail.com',name,"CREDIWATCH_TEAM",tick_num,status)
                    print("*****************")
                    cursor.execute(
                    """INSERT INTO 
                        banking (
                            cname,
                            cin,
                            LOAN_STATUS
                            )
                    VALUES (%s,%s,%s)""", (company_info["COMPANY NAME"], company_info["CIN"], status))
                    mysql.connection.commit()
                except Exception as e:
                    print(e,"here")
                    pass
                msg = "Yes, You can provide loan to this company"
            else:
                status = "No"
                ans=mail_details([str3],'ravivarma.vemagiri@gmail.com',name,"CREDIWATCH_TEAM",tick_num,status)
                cursor.execute(
                """INSERT INTO 
                    banking (
                        cname,
                        cin,
                        LOAN_STATUS
                        )
                VALUES (%s,%s,%s)""", (company_info["COMPANY NAME"], company_info["CIN"], status))
                mysql.connection.commit()
                msg = "No, You cannot provide loan to this company."
            return render_template('home-1.html',msg=msg,num=num_inf)
        else:
            #handle CIN wrong input.
            d_check = es_search(es_object, "company_data", cname)
            if len(d_check)>0:
                msg = "Sorry. Loan cannot be processed as CIN number is mispelled."
                num = 'Status: Cannot process the Loan'
            else:
                msg = "Sorry. Our team found that your company is not registered."
                num = 'Status: Cannot process the Loan'
            return render_template('home-1.html',msg=msg,num=num)
    return redirect(url_for('home'))

@app.route('/t_process', methods=['GET', 'POST','post'])
def t_process():
    if request.method == 'POST':
        t_num = int(request.form['t_num'])
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        if t_num>=1 and t_num<=2:
            query_string = "select * from banking WHERE LOAN_STATUS = %s"
            number_of_rows = cursor.execute(query_string, ("No",));
            result = cursor.fetchall()
        elif t_num>2 and t_num<=6:
            query_string = "select * from banking WHERE LOAN_STATUS = %s"
            number_of_rows = cursor.execute(query_string, ("Yes",));
            result = cursor.fetchall()
        return render_template('bank_dashboard.html',loan_views=result)
    return render_template('bank_login.html', msg='')

            


@app.route('/home')
def home():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        return render_template('home.html', username=session['username'])
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    # Check if user is loggedin
    if 'loggedin' in session:
        # We need all the account info for the user so we can display it on the profile page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE id = %s', [session['id']])
        account = cursor.fetchone()
        # Show the profile page with account info
        return render_template('profile.html', account=account)
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port='8000', debug=True)