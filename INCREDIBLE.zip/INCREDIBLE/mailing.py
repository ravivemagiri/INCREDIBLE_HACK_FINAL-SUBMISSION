import smtplib
import glob
import getpass
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase

def py_mail(SUBJECT, BODY, TO, FROM):
    """With this function we send out our html email"""
 
    # Create message container - the correct MIME type is multipart/alternative here @ravi CE!
    CC_LIST=["N140976@rguktn.ac.in","ravivarma.vemagiri@gmail.com"]
    MESSAGE = MIMEMultipart('alternative')
    MESSAGE['subject'] = SUBJECT
    MESSAGE['To'] = ",".join(TO)
    MESSAGE['From'] = FROM
    MESSAGE['Cc'] = ",".join(CC_LIST)
    # Record the MIME type text/html.
    HTML_BODY = MIMEText(BODY, 'html')
 
    # Attach parts into message container.
    MESSAGE.attach(HTML_BODY)
    #to add an attachment is just add a MIMEBase object to read a picture locally.
    # im_names=glob.glob('static/styles/assets/uploads/'+'*.png')
    # domain_names=["Baby Products","Garden Products","Health Products","Video Products","Audio Products"]
    # for x in range(len(im_names)):
    #     with open(im_names[x], 'rb') as f:
    #         # set attachment mime and file name, the image type is png
    #         mime = MIMEBase('image', 'png', filename='report'+str(x+1)+'.png')
    #         # add required header data:
    #         mime.add_header('Content-Disposition', 'attachment', filename='report - '+domain_names[x]+'.png')
    #         mime.add_header('X-Attachment-Id', str(x))
    #         mime.add_header('Content-ID', '<'+str(x)+'>')
    #         # read attachment file content into the MIMEBase object
    #         mime.set_payload(f.read())
    #         # encode with base64
    #         encoders.encode_base64(mime)
    #         # add MIMEBase object to MIMEMultipart object
    #         MESSAGE.attach(mime)
    #password = getpass.getpass() 
    password="MAIL_PASSWORD_HERE"
    # The actual sending of the e-mail
    print("Reached here")
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()
    print(FROM,password)
    server.login(FROM, password)
    TO=TO+CC_LIST
    server.sendmail(FROM,TO, MESSAGE.as_string())
    server.close()
    return True

def mail_details(recipients,FROM,name,str5,tick,status):
    print("Entered Here")
    #empty-cells:hide;
    n1=3
    n2=4
    n3=5
    n4=6
    if status=="Yes":
      email_content = '''
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>html title</title>
    <head>
    <style type="text/css">
    table, td, th {  
      border: 1px solid #ddd;
      text-align: left;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }
    th{
     background-color:#3b5998;
     color:white;
    }
    th, td {
      padding: 15px;
    }
    tr:hover {background-color:#f5f5f5;}
    .notepaper {
      position: relative;
      margin: 30px auto;
      padding: 29px 20px 20px 45px;
      width: 280px;
      line-height: 30px;
      color: #6a5f49;
      text-shadow: 0 1px 1px white;
      background-color: #f2f6c1;
      background-image: -webkit-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -webkit-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      background-image: -moz-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -moz-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      background-image: -o-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -o-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      border: 1px solid #c3baaa;
      border-color: rgba(195, 186, 170, 0.9);
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      -webkit-box-shadow: inset 0 1px rgba(255, 255, 255, 0.5), inset 0 0 5px #d8e071, 0 0 1px rgba(0, 0, 0, 0.1), 0 2px rgba(0, 0, 0, 0.02);
      box-shadow: inset 0 1px rgba(255, 255, 255, 0.5), inset 0 0 5px #d8e071, 0 0 1px rgba(0, 0, 0, 0.1), 0 2px rgba(0, 0, 0, 0.02);
    }

    .notepaper:before, .notepaper:after {
      content: '';
      position: absolute;
      top: 0;
      bottom: 0;
    }

    .notepaper:before {
      left: 28px;
      width: 2px;
      border: solid #efcfad;
      border-color: rgba(239, 207, 173, 0.9);
      border-width: 0 1px;
    }

    .notepaper:after {
      z-index: -1;
      left: 0;
      right: 0;
      background: rgba(242, 246, 193, 0.9);
      border: 1px solid rgba(170, 157, 134, 0.7);
      -webkit-transform: rotate(2deg);
      -moz-transform: rotate(2deg);
      -ms-transform: rotate(2deg);
      -o-transform: rotate(2deg);
      transform: rotate(2deg);
    }

    .quote {
      font-family: Georgia, serif;
      font-size: 14px;
    }

    .curly-quotes:before, .curly-quotes:after {
      display: inline-block;
      vertical-align: top;
      height: 30px;
      line-height: 48px;
      font-size: 50px;
      opacity: .2;
    }

    .curly-quotes:before {
      content: '\201C';
      margin-right: 4px;
      margin-left: -8px;
    }

    .curly-quotes:after {
      content: '\201D';
      margin-left: 4px;
      margin-right: -8px;
    }

    .quote-by {
      display: block;
      padding-right: 10px;
      text-align: right;
      font-size: 13px;
      font-style: italic;
      color: #84775c;
    }

    .lt-ie8 .notepaper {
      padding: 15px 25px;
    }
    .contain {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
      width:500px;
      font-size: 14px;
      color:green;
    }
    </style>

    </head>
    <body>
    <p>Hi, '''+name+''' <br/>Congratulations!!. I'm Crediwatch Bot and i'm here with a good news, that your loan process has been initialised and you are eligible for having loan.</p>
    <p>Bank will be contacting you soon..</p>
    </body>
    </html>
    '''

    else:

      email_content = '''
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>html title</title>
    <head>
    <style type="text/css">
    table, td, th {  
      border: 1px solid #ddd;
      text-align: left;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }
    th{
     background-color:#3b5998;
     color:white;
    }
    th, td {
      padding: 15px;
    }
    tr:hover {background-color:#f5f5f5;}
    .notepaper {
      position: relative;
      margin: 30px auto;
      padding: 29px 20px 20px 45px;
      width: 280px;
      line-height: 30px;
      color: #6a5f49;
      text-shadow: 0 1px 1px white;
      background-color: #f2f6c1;
      background-image: -webkit-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -webkit-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      background-image: -moz-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -moz-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      background-image: -o-radial-gradient(center, cover, rgba(255, 255, 255, 0.7) 0%, rgba(255, 255, 255, 0.1) 90%), -o-repeating-linear-gradient(top, transparent 0%, transparent 29px, rgba(239, 207, 173, 0.7) 29px, rgba(239, 207, 173, 0.7) 30px);
      border: 1px solid #c3baaa;
      border-color: rgba(195, 186, 170, 0.9);
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      -webkit-box-shadow: inset 0 1px rgba(255, 255, 255, 0.5), inset 0 0 5px #d8e071, 0 0 1px rgba(0, 0, 0, 0.1), 0 2px rgba(0, 0, 0, 0.02);
      box-shadow: inset 0 1px rgba(255, 255, 255, 0.5), inset 0 0 5px #d8e071, 0 0 1px rgba(0, 0, 0, 0.1), 0 2px rgba(0, 0, 0, 0.02);
    }

    .notepaper:before, .notepaper:after {
      content: '';
      position: absolute;
      top: 0;
      bottom: 0;
    }

    .notepaper:before {
      left: 28px;
      width: 2px;
      border: solid #efcfad;
      border-color: rgba(239, 207, 173, 0.9);
      border-width: 0 1px;
    }

    .notepaper:after {
      z-index: -1;
      left: 0;
      right: 0;
      background: rgba(242, 246, 193, 0.9);
      border: 1px solid rgba(170, 157, 134, 0.7);
      -webkit-transform: rotate(2deg);
      -moz-transform: rotate(2deg);
      -ms-transform: rotate(2deg);
      -o-transform: rotate(2deg);
      transform: rotate(2deg);
    }

    .quote {
      font-family: Georgia, serif;
      font-size: 14px;
    }

    .curly-quotes:before, .curly-quotes:after {
      display: inline-block;
      vertical-align: top;
      height: 30px;
      line-height: 48px;
      font-size: 50px;
      opacity: .2;
    }

    .curly-quotes:before {
      content: '\201C';
      margin-right: 4px;
      margin-left: -8px;
    }

    .curly-quotes:after {
      content: '\201D';
      margin-left: 4px;
      margin-right: -8px;
    }

    .quote-by {
      display: block;
      padding-right: 10px;
      text-align: right;
      font-size: 13px;
      font-style: italic;
      color: #84775c;
    }

    .lt-ie8 .notepaper {
      padding: 15px 25px;
    }
    .contain {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
      width:500px;
      font-size: 14px;
      color:green;
    }
    </style>

    </head>
    <body>
    <p>Hi, '''+name+''' <br/>We are sorry!!. I'm Crediwatch Bot and im here with a news, that you are not eligible for having loan as your company did not meet our requirements.</p>
    <p>Bank will be contacting you soon..</p>
    </body>
    </html>
    '''
    #recipients = ['ravivarma.vemagiri@gmail.com']
    FROM ='ravivarma.vemagiri@gmail.com'
    subj="Loan Eligibility Status for Ticket Id: "+tick
    msg=py_mail(subj, email_content, recipients, FROM)
    return msg