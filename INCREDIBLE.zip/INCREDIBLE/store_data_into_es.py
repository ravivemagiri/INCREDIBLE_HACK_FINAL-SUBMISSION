#import necessary modules
import csv
import pdb
import json
from elasticsearch import Elasticsearch
from elasticsearch import helpers


def get_csv_data(file_path):
    reader = csv.DictReader(open(file_path))
    data_records = []
    for raw in reader:
        data_records.append(dict(raw))
    return data_records

def create_index(es_object, index_name = 'my_athina'):
    created = False
    try:
        if not es_object.indices.exists(index_name):
            # Ignore 400 means to ignore "Index Already Exist" error.
            status = es_object.indices.create(index=index_name,ignore=400)
        created = True
    except Exception as e:
        print ("Exception occured in create_index: ", str(e))
    finally:
        return (created)

def es_search(es_object, index_name, search_string):
    query_res = []
    search_object = {'query': {'match': {'COMPANY NAME': {'query':search_string,"operator": "and"}}}}
    json_obj = json.dumps(search_object)
    query_output_dic = es_object.search(index=index_name, body=json_obj)
    for res_record in query_output_dic['hits']['hits']:
        record_dic = res_record['_source']
        record_dic['_id']= res_record['_id']
        query_res.append(record_dic)
    return query_res

def bulk_indexing(es_object, index_name, doc_type, records):
    """
    Bulk Indexing the documents.
    """
    documents_list = []
    try:
        for record in records:
            hash_id = record['CIN']
            document = {
                "_index": index_name,
                "_type": doc_type,
                "_id": hash_id,
                "_source": record
                }
            documents_list.append(document)
        status = helpers.bulk(es_object, documents_list, chunk_size=10)
        if (status[0] != len(records)):
            print("Error in bulk_indexing.")
    except Exception as e:
        print ('Exception occured in bulk_indexing: ', str(e))

def get_company_info(es_object, index_name, cin):
    reg_sta = {'registration_status':False}
    if es_object.exists(index=index_name,id=cin):
        company_details = es_object.get(index=index_name,id=cin)
        reg_sta['registration_status'] = True
        reg_sta.update(company_details['_source'])
    return reg_sta



file_path = "dataset.csv"
list_of_records = get_csv_data(file_path)

es_object = Elasticsearch([{'host': 'localhost', 'port': 9200}])
# pdb.set_trace()
if es_object.ping():
    try:
        status = create_index(es_object, 'company_data')
        if (status):
            # pdb.set_trace()
            store_data_in_es = bulk_indexing(es_object, 'company_data', 'company_info', list_of_records)
            #store_data_in_es = store_record(es_object, 'athina', list_of_records)
        else:
            print("Error in index creation.")
    except Exception as e:
        print('Exception in driver program: ', str(e))
else:
    print('ES object is down')

# pdb.set_trace()
# print('debug point')